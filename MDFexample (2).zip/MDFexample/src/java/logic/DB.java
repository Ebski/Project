/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author Dennis
 */
public class DB {
    public static String driver = "oracle.jdbc.driver.OracleDriver";
    public static String URL = "jdbc:oracle:thin:@datdb.cphbusiness.dk:1521:dat";
    public static String user = "cphda68";
    public static String password = "cphda68";
}